=== Plugin Name ===
Contributors: smoo1337
Donate link: http://conversion-junkies.de
Tags: cookies, privacy
Requires at least: 3.5.1
Tested up to: 4.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The plugin uses the google Cookiechoice.de guideline and javascript library.
Its handle the integration easy for all wordpress users.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the pluginfolder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Plugins -> CookieChoice
1. Fill out the form and active the integration.
1. show the cookie information and get happy

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0 =
* first version starts